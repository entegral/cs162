#include <iostream>
using namespace std;

int main()
{
	cout << "\nHello world, I've been on an adventure!" << endl;
	cout << "I was compiled on PCC's Linux Server, then tarballed," << endl;
	cout << "emailed, downloaded via ftp, and then finally uploaded to you!\n" << endl;
	return 0;
}
